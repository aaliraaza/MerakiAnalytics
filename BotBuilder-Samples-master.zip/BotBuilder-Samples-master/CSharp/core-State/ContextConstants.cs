﻿namespace StateBot
{
    public class ContextConstants
    {
        public const string UserNameKey = "UserName";

        public const string CityKey = "City";
    }
}