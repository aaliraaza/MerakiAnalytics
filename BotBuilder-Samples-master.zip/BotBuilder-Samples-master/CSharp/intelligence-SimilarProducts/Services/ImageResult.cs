﻿namespace SimilarProducts.Services
{
    public class ImageResult
    {
        public string HostPageDisplayUrl { get; set; }

        public string HostPageUrl { get; set; }

        public string Name { get; set; }

        public string ThumbnailUrl { get; set; }

        public string WebSearchUrl { get; set; }
    }
}