﻿namespace SimilarProducts.Services
{
    public class BingImageAggregateRating
    {
        public double RatingValue { get; set; }

        public double BestRating { get; set; }
    }
}