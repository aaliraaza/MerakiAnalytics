﻿namespace SimilarProducts.Services
{
    public class BingImageThumbnail
    {
        public int Width { get; set; }

        public int Height { get; set; }
    }
}