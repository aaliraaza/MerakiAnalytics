﻿namespace SimilarProducts.Services
{
    public class BingImageInstrumentation
    {
        public string PageLoadPingUrl { get; set; }
    }
}
