﻿namespace Zummer.Models.Search
{
    public class ZummerSearchResult
    {
        public string Tile { get; set; }

        public string Url { get; set; }

        public string Query { get; set; }

        public string Snippet { get; set; }
    }
}