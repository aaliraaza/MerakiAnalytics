﻿namespace LuisBot.Services
{
    public class BingSpellCheckError
    {
        public int StatusCode { get; set; }

        public string Message { get; set; }
    }
}
