## PowerShell

```
PS> .\deploy.ps1 -subscriptionId e3f93473-d01a-4311-84bd-f292f96bf83f  -resourceGroupName ADL_Dev -deploymentName rgdshdidev
```
